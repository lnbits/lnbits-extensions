# LNURLPayOut

## Auto-dump a wallets funds to an LNURLpay
