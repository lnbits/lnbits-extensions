# StreamerCopilot

Tool to help streamers accept sats for tips
