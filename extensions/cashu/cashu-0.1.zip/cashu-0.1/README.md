# Cashu 

## Create ecash mint for pegging in/out of ecash



### Usage

1. Enable extension
2. Create a Mint
3. Share wallet
