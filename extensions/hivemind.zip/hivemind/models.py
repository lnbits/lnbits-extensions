# from sqlite3 import Row
# from typing import NamedTuple


# class Example(NamedTuple):
#    id: str
#    wallet: str
#
#    @classmethod
#    def from_row(cls, row: Row) -> "Example":
#        return cls(**dict(row))
