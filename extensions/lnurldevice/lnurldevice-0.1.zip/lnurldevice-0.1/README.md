# LNURLDevice

For offline LNURL devices

`Authur: Ben Arc`
