# Pegged Assets

## Keep a pegged balance in a wallet

ALL funds initally in the wallet and all funds added later to the wallet will be pegged to FIAT currency, or basket of asset (coming soon) value. The extension essentially allows creating *synthetic stablecoins* by means of Perpetual Futures contract on the external exchange. Although it implies counterparty risk due to reliance on centralized exchange, the user gets more liquid markes and less expensive funding.

### Creating a peg

1. Enable extension
2. Add kollider detais (should be on your own LNbits, or an install you trust very much)
3. Name the peg, select a wallet, select a percentage of the funds that should be pegged (80% max, 20% min float for trades)
4. Select a currency

## Warning

Please, mind custodial and security risks while using this extension. The software is provided "as it is" without any guarantees whatsoever.

**Your funds at the exchange are in constant risk of being stolen**. Choose wisely percentage of hedged sats and amount of funds stored at the exchange.

## Acknowledgment

Standard Sats Team maintains this LNBits extension.

* [Website](https://standardsats.github.io/)
* [Telegram](https://t.me/StandardSatsCommunity)
* [GitHub](https://github.com/standardsats)

