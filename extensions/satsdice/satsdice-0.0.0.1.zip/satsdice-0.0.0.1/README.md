# satsdice

## Create staic LNURL powered satsdices

Gambling is dangerous, flip responsibly
