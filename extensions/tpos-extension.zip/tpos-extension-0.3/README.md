# TPoS

## A Shareable PoS (Point of Sale) that doesn't need to be installed and can run in the browser!

An easy, fast and secure way to accept Bitcoin, over Lightning Network, at your business. The PoS is isolated from the wallet, so it's safe for any employee to use. You can create as many TPOS's as you need, for example one for each employee, or one for each branch of your business.

### Usage

1. Enable extension
2. Create a TPOS\
   ![create](https://imgur.com/8jNj8Zq.jpg)
3. Open TPOS on the browser\
   ![open](https://imgur.com/LZuoWzb.jpg)
4. Present invoice QR to customer\
   ![pay](https://imgur.com/tOwxn77.jpg)
