<h1>Tip Jars</h1>
<h2>Accept tips in Bitcoin, with small messages attached!</h2>
The TipJar extension allows you to integrate Bitcoin Lightning (and on-chain) tips into your website or social media!

![image](https://user-images.githubusercontent.com/28876473/134997129-c2f3f13c-a65d-42ed-a9c4-8a1da569d74f.png)

<h2>How to set it up</h2>

1. Simply create a new Tip Jar with the desired details (onchain optional):  
![image](https://user-images.githubusercontent.com/28876473/134996842-ec2f2783-2eef-4671-8eaf-023713865512.png)
1. Share the URL you get from this little button:  
![image](https://user-images.githubusercontent.com/28876473/134996973-f8ed4632-ea2f-4b62-83f1-1e4c6b6c91fa.png)


<h3>And that's it already! Let the sats flow!</h3>
