# crud.py is for communication with your extensions database

# add your dependencies here

# add your fnctions here
